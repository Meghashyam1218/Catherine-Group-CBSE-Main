<script>
    import ListOfItems from "./components/ListOfItems.svelte";
    import Top from "$lib/components/top.svelte"
    import Footer from "$lib/components/footer.svelte"
</script>

<Top name="Mandatory Disclosure" heading="Mandatory Disclosure"/>
<ListOfItems/>
<Footer/>
