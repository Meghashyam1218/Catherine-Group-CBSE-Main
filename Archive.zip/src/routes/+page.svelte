<script>

import Hero from "$lib/components/hero.svelte";
import Navbar from "$lib/components/navbar.svelte";
import Why from "$lib/components/why.svelte";
import Cards from "$lib/components/cards.svelte"
import Highlights from "$lib/components/highlights.svelte";
import Top from "$lib/components/top.svelte";
import Footer from "$lib/components/footer.svelte";
</script>


<section class="">
<div class="">
    <!-- <Top/> -->
    <Hero/>
    <Why/>
    <Highlights/>
    <Cards/>
    <Footer/>

</div>
</section>