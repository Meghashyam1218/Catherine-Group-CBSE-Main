<section>
    <div class="h-[75vh] my-7 flex flex-col justify-center items-center rounded-[2em] bg-[radial-gradient(ellipse_at_top,_var(--tw-gradient-stops))] from-blue-500 via-cyan-700 to-purple-700   ">
        <h1 class="text-white text-6xl md:text-9xl font-extrabold text-center">JOIN US</h1>
        <h1 class="text-white text-6xl md:text-9xl font-extrabold text-center">NOW </h1>
        <h1 class="text-white text-2xl md:text-4xl my-2  text-center">Let be the Part of Our Institute </h1>
        <a href="">
            <div class="bg-white  flex items-center justify-center px-4 md:px-6 py-2 md:py-4 rounded-full m-4 hover:bg-indigo-900 hover:text-white  hover:fill-white    "  >
                <svg
                        class=" rotate-[135deg] "
                        width="25pt"
                        height="25pt"
                        viewBox="0 0 100.000000 100.000000"
                        preserveAspectRatio="xMidYMid meet"
                    >
                        <g class=""
                            transform="translate(0.000000,100.000000) scale(0.100000,-0.100000)"
                            
                            stroke="none"
                        >
                            
                            <path
                                d="M325 590 l-90 -90 92 -92 c73 -73 95 -90 105 -80 10 10 -2 27 -57 82
                        l-69 70 224 2 c192 3 225 5 225 18 0 13 -33 15 -225 18 l-224 2 68 69 c59 60
                        76 91 48 91 -4 0 -48 -41 -97 -90z"
                            />
                        </g>
                    </svg>
                <h1 class="text-center text-xl">Click to Join</h1>
            </div>
        </a>
    </div>
</section>