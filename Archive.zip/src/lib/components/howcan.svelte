<section class="h-[180vh] bg-[#eff3f3]">
    <div class="h-[180vh] pl-[20vh] pt-[20vh] flex flex-row justify-between">
        <div class="flex flex-col h-[170vh] w-[40vw] justify-between">
            <div class="h-[60%]">
                <p class="font-extrabold text-start 3xs:text-4xl 2xs:text-5xl md:text-8xl">
                    HOW CAN YOU USE OCEAN SCHOOL IN YOUR CLASSROOM? FREE, ENGAGING, INFORMATIVE
                </p>
            </div>
            <div class="h-[20%] grid place-items-start">
                <button class="bg-[#0c1637] shadow-2xl shadow-gray-600 text-white xl:text-xl text-base font-semibold p-2 xl:p-4 rounded-full duration-700 hover:bg-white hover:text-[#0c1637]">
                    Explore Our Resources
                </button>
            </div>
        </div>
        <div class="flex flex-col h-[170vh] w-[50vw] py-[10]">
            <div class="h-[50vh] relative grid items-center justify-end">
                <div class="flex flex-row h-[15vh] w-[25vw] shadow-2xl bg-white mr-6 rounded-[30px]">
                    <div class="absolute top-0 left-52"><img src="./step1.svg"></div>
                    <div class="grid grid-cols-2 place-items-end">
                        <div class="self-center justify-end mr-6">
                            <div class="h-[30px] w-[30px] grid place-items-center rounded-[300px] bg-black text-white">
                                1
                            </div>
                        </div>
                        <div class="self-center">
                            <div class="">
                                <p class="font-bold">Select a collection</p>
                                <p>and customize it</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="h-[50vh] relative grid items-center justify-center pl-[20%] pt-[10%]">
                <div class="flex flex-row h-[20vh] w-[25vw] shadow-2xl bg-white mr-6 rounded-[30px]">
                    <div class="absolute top-5 left-14"><img src="./step2.svg" class=""></div>
                    <div class="grid grid-cols-2 place-items-end">
                        <div class="self-center justify-end mr-6">
                            <div class="h-[30px] w-[30px] grid place-items-center rounded-[300px] bg-black text-white">
                                2
                            </div>
                        </div>
                        <div class="self-center">
                            <div class="">
                                <p class="font-bold">Select a collection</p>
                                <p>and customize it</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="h-[50vh] relative grid items-end justify-end pb-[10%]">
                <div class="flex flex-row  h-[25vh] w-[25vw] shadow-2xl bg-white mr-6 rounded-[30px]">
                    <div class="absolute top-20 left-56"><img src="./step3.svg"></div>
                    <div class="grid grid-cols-2 place-items-end">
                        <div class="self-center justify-end mr-6">
                            <div class="h-[30px] w-[30px] grid place-items-center rounded-[300px] bg-black text-white">
                                3
                            </div>
                        </div>
                        <div class="self-center">
                            <div class="">
                                <p class="font-bold">Select a collection</p>
                                <p>and customize it</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>