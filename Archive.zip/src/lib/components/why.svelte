<section class="h-90vh">
    <div class="flex 3xs:flex-col xl:flex-row m-[10%]">
        <div class="flex flex-col xl:w-[50vw]">
            <div><p class="xl:text-3xl 3xs:text-2xl font-semibold">What is Ocean School?</p></div>
            <div class="mt-[5%] xl:mr-[10%]"><p class="xl:text-xl text-base text-justify leading-8">Ocean School is a free environmental education resource for students in grades 5-12. Our inspiring and immersive multimedia resources featuring linear and 360˚ videos, VR/AR, interactive media and hands-on projects and activities are offered in English and French. Our cross-curricular content spans science, social studies, language arts and more!</p></div>
            <div class="mt-[5%] 3xs:grid 3xs:self-center xl:self-start"><button class="bg-[#0c1637] text-white xl:text-xl text-base font-semibold p-2 xl:p-4 rounded-full duration-700 hover:bg-white hover:text-[#0c1637]">Explore Our Resources</button></div>
        </div>
        <div class="flex flex-col xl:w-[40vw] pt-[5%] xl:pl-[5%] space-y-6">
            <div><p class="xl:text-xl text-base text-justify leading-8">Explore the ocean through immersive multimedia lessons created by scientists, educators, and storytellers.</p></div>
            <div class="pt-[5%]"><img src="./fish.webp" class=""></div>
        </div>
    </div>
</section>