<section class="">
	<div
		class="h-[60vh] bg-gradient-to-tl from-indigo-400 via-blue-400 to-current rounded-[2rem] m-4 flex flex-col justify-center items-center md:items-start"
	>
		<h1 class="text-white  md:ml-24 text-sm mt-10"><a href="" class="hover:opacity-75">Home</a> - Admission</h1>
		<h1 class="text-white  font-bold text-6xl md:text-8xl md:ml-24 mt-6 md:mt-12">ADMISSION </h1>
	</div>

    <div class="w-[75vw] lg:w-[60vw] ml-auto mr-auto  mt-12">
        <h1 class="text-4xl md:text-5xl font-semibold text-indigo-900">Dive into the new Ocean School experience! </h1>
        <br>
        <br>
        <h1 class="text-2xl font-light">We have new features and a new look!</h1>
        <br><br>
        <p class="text-base lg:text-xl text-gray-700">We have introduced some new features that we hope you’ll love! We've worked with teachers and students to make the site more user-friendly!
            <br>
            <br>
            You'll find all the tools you need at Ocean School to get started right away. It’s easier than ever!
        </p>
    </div>
</section>
