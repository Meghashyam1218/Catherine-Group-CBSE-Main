<script>
</script>

<section data-aos="fade-up" class="flex flex-col  max-md:items-center my-20">
	<div
		class="events-head  w-[90vw] mx-auto flex flex-col md:flex-row justify-between items-center p-4"
	>
		<h1
			class="md:text-6xl text-3xl 2xs:text-4xl font-black lg::basis-3/4 text-gray-800 md:m-4 md:ml-6"
		>
			Our Highlights
		</h1>
		<div class="lg:flex hidden lg:basis-1/4 scale-[0.7] md:scale-[1] justify-end md:mr-20">
			<div class="arrow-left pointer-events-none  opacity-0 rotate-0 md:ml-6">
				<svg
					width="50pt"
					height="50pt"
					viewBox="0 0 100.000000 100.000000"
					preserveAspectRatio="xMidYMid meet"
				>
					<g
						transform="translate(0.000000,100.000000) scale(0.100000,-0.100000)"
						fill="rgb(66, 66, 66)"
						stroke="none"
					>
						<path
							d="M386 944 c-225 -54 -376 -286 -338 -517 62 -367 512 -513 773 -252
                    329 330 18 879 -435 769z m219 -39 c312 -81 418 -473 191 -701 -241 -240 -651
                    -107 -709 230 -50 295 226 546 518 471z"
						/>
						<path
							d="M325 590 l-90 -90 92 -92 c73 -73 95 -90 105 -80 10 10 -2 27 -57 82
                    l-69 70 224 2 c192 3 225 5 225 18 0 13 -33 15 -225 18 l-224 2 68 69 c59 60
                    76 91 48 91 -4 0 -48 -41 -97 -90z"
						/>
					</g>
				</svg>
			</div>
			<div class="arrow-right pointer-events-none opacity-0 rotate-180 md:ml-6">
				<svg
					width="50pt"
					height="50pt"
					viewBox="0 0 100.000000 100.000000"
					preserveAspectRatio="xMidYMid meet"
				>
					<g
						transform="translate(0.000000,100.000000) scale(0.100000,-0.100000)"
						fill="rgb(66, 66, 66)"
						stroke="none"
					>
						<path
							d="M386 944 c-225 -54 -376 -286 -338 -517 62 -367 512 -513 773 -252
                    329 330 18 879 -435 769z m219 -39 c312 -81 418 -473 191 -701 -241 -240 -651
                    -107 -709 230 -50 295 226 546 518 471z"
						/>
						<path
							d="M325 590 l-90 -90 92 -92 c73 -73 95 -90 105 -80 10 10 -2 27 -57 82
                    l-69 70 224 2 c192 3 225 5 225 18 0 13 -33 15 -225 18 l-224 2 68 69 c59 60
                    76 91 48 91 -4 0 -48 -41 -97 -90z"
						/>
					</g>
				</svg>
			</div>
		</div>
	</div>
	<div
		class="highlights md:scale-[0.75] lg:scale-[1] lg:gap-2 gap-8 md:flex-row md:flex w-[95vw] justify-evenly"
	>
		<div class="highlight w-[311px] mx-auto relative">
			<div class="highlight-bg1">
				<svg
					class="mx-auto"
					id="b04def02-ba54-4ac5-a00f-6895f4cb19fb"
					data-name="Layer 1"
					xmlns="http://www.w3.org/2000/svg"
					xmlns:xlink="http://www.w3.org/1999/xlink"
					viewBox="0 0 269 258"
					width="269"
					height="258"
					role="img"
					><defs
						><style>
							.acb2ec8b-8a46-4592-b6d1-c6a4b28d1be4 {
								fill-opacity: 0.85;
								fill: url(#add77119-e861-4ef0-87bc-5a45a27fa18e);
							}

							.f574b5c2-11fa-4c57-8d31-f76b9abf5680 {
								fill-opacity: 0.9;
								fill: url(#b8b47d88-c688-436c-bc48-81eb1ba46f34);
							}

							.b535b87f-b7cd-4d21-8133-b709b021cf33 {
								fill: url(#e30480d6-ec9d-403c-a112-d231046411d3);
							}
						</style>
						<radialGradient
							id="add77119-e861-4ef0-87bc-5a45a27fa18e"
							cx="-813.69"
							cy="682.8"
							r="1"
							gradientTransform="matrix(119.53, -203.26, -242.99, -142.88, 263271.54, -67619.23)"
							gradientUnits="userSpaceOnUse"
							><stop offset="0" stop-color="#fcacf1" /> <stop offset="0.45" stop-color="#fcacf1" />
							<stop offset="0.74" stop-color="#fe9887" />
							<stop offset="1" stop-color="#ef4225" /></radialGradient
						>
						<radialGradient
							id="b8b47d88-c688-436c-bc48-81eb1ba46f34"
							cx="-813.57"
							cy="681.33"
							r="1"
							gradientTransform="matrix(81.75, -140.07, -166.83, -97.36, 180213, -47382.16)"
							gradientUnits="userSpaceOnUse"
							><stop offset="0" stop-color="#7fdddd" /> <stop offset="0.45" stop-color="#7fdddd" />
							<stop offset="0.74" stop-color="#33d2c9" />
							<stop offset="1" stop-color="#1aa9e8" /></radialGradient
						>
						<radialGradient
							id="e30480d6-ec9d-403c-a112-d231046411d3"
							cx="-813.46"
							cy="680.39"
							r="1"
							gradientTransform="matrix(68.12, -115.85, -138.49, -81.44, 149833.55, -38560.75)"
							gradientUnits="userSpaceOnUse"
							><stop offset="0.45" stop-color="#ffd953" />
							<stop offset="0.74" stop-color="#fbab33" />
							<stop offset="1" stop-color="#ef8523" /></radialGradient
						></defs
					> <circle cx="142.5" cy="96.5" r="96.5" class="acb2ec8b-8a46-4592-b6d1-c6a4b28d1be4" />
					<ellipse
						cx="66"
						cy="159.5"
						rx="66"
						ry="66.5"
						class="f574b5c2-11fa-4c57-8d31-f76b9abf5680"
					/> <circle cx="214" cy="203" r="55" class="b535b87f-b7cd-4d21-8133-b709b021cf33" /></svg
				>
			</div>

			<div class="content-h absolute top-[33%] left-[15%] ">
				<span class="text-5xl font-bold">Educators</span>
				<button class="arrow-h"
					><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 25" role="img"
						><path
							fill-rule="evenodd"
							clip-rule="evenodd"
							d="M16.961 18.085a.459.459 0 0 0 .023.68.545.545 0 0 0 .732-.02l5.648-5.592.333-.33-.333-.33-5.572-5.516a.545.545 0 0 0-.732-.02.459.459 0 0 0-.023.68l4.76 4.712H.713c-.276 0-.5.224-.498.5 0 .276.226.5.502.5h21.028l-4.784 4.736Z"
						/></svg
					></button
				>
			</div>
		</div>
		<div class="highlight w-[311px] mx-auto relative">
			<div class=" highlight-bg2">
				<svg
					class="mx-auto"
					id="f9716a2a-57aa-406d-b398-b9f1288e2f67"
					data-name="Layer 1"
					xmlns="http://www.w3.org/2000/svg"
					xmlns:xlink="http://www.w3.org/1999/xlink"
					viewBox="0 0 282.42 282.43"
					width="282"
					height="282"
					role="img"
					><defs
						><radialGradient
							id="fb5d315b-08cf-4901-8ade-0d822e6a6e70"
							cx="-804.98"
							cy="696.66"
							r="1"
							gradientTransform="matrix(222.86, 131.03, 156.64, -266.4, 70300.74, 291182.92)"
							gradientUnits="userSpaceOnUse"
							><stop offset="0" stop-color="#7fdddd" /> <stop offset="0.45" stop-color="#7fdddd" />
							<stop offset="0.74" stop-color="#33d2c9" />
							<stop offset="1" stop-color="#1aa9e8" /></radialGradient
						>
						<radialGradient
							id="b2cc80a4-2f7a-4644-b0ce-c70d4ada74b0"
							cx="-803.56"
							cy="669.34"
							r="1"
							gradientTransform="matrix(142.04, -71.96, -10.74, -21.19, 121325.86, -43387.14)"
							gradientUnits="userSpaceOnUse"
							><stop offset="0.45" stop-color="#ef8523" />
							<stop offset="0.74" stop-color="#fbab33" />
							<stop offset="1" stop-color="#ffd953" /></radialGradient
						></defs
					>
					<rect
						x="47.29"
						y="52.12"
						width="211.6"
						height="211.58"
						rx="10"
						transform="translate(-72.62 192.68) rotate(-59.42)"
						style="fill-opacity:0.8999999761581421;fill:url(#fb5d315b-08cf-4901-8ade-0d822e6a6e70)"
					/>
					<path
						d="M146,174.43h0a7,7,0,0,1-2.57,9.6L24.8,252.49a7,7,0,0,1-9.59-2.57h0a7,7,0,0,1,2.57-9.6l118.58-68.46A7,7,0,0,1,146,174.43Z"
						transform="translate(-11.89 -16.7)"
						style="fill:url(#b2cc80a4-2f7a-4644-b0ce-c70d4ada74b0)"
					/></svg
				>
			</div>
			<div class="content-h absolute top-[33%] left-[0%] ">
				<span class="text-5xl font-bold">Infrastructure</span>
				<button class="arrow-h"
					><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 25" role="img"
						><path
							fill-rule="evenodd"
							clip-rule="evenodd"
							d="M16.961 18.085a.459.459 0 0 0 .023.68.545.545 0 0 0 .732-.02l5.648-5.592.333-.33-.333-.33-5.572-5.516a.545.545 0 0 0-.732-.02.459.459 0 0 0-.023.68l4.76 4.712H.713c-.276 0-.5.224-.498.5 0 .276.226.5.502.5h21.028l-4.784 4.736Z"
						/></svg
					></button
				>
			</div>
		</div>
		<div class="highlight w-[311px] mx-auto relative">
			<div class="highlight-bg3">
				<svg
					class="mx-auto"
					id="b055d3c0-9e4d-4559-957e-8bb1de712b90"
					data-name="Layer 1"
					xmlns="http://www.w3.org/2000/svg"
					xmlns:xlink="http://www.w3.org/1999/xlink"
					viewBox="0 0 311.01 267.37"
					width="311"
					height="267"
					role="img"
					><defs
						><style>
							.e6a19419-ca4e-4fc8-919d-c225b495789d {
								fill: url(#b3ab2035-4d74-4988-bfaf-023d653d93e3);
							}

							.ff645115-978f-4749-91b7-0655df25f0da {
								fill: url(#a472a647-94c4-48a3-a4ff-c546c6d0522e);
							}

							.f4cdc8fd-f942-49df-83d2-702a58c7e32f {
								fill: url(#e5d1713c-65a6-46d4-9d69-0c85940c7ca1);
							}
						</style>
						<radialGradient
							id="b3ab2035-4d74-4988-bfaf-023d653d93e3"
							cx="-772.29"
							cy="718.51"
							r="1"
							gradientTransform="matrix(102.14, -111.82, -133.67, -122.1, 175142, 1510.77)"
							gradientUnits="userSpaceOnUse"
							><stop offset="0" stop-color="#7fdddd" /> <stop offset="0.45" stop-color="#7fdddd" />
							<stop offset="0.74" stop-color="#33d2c9" />
							<stop offset="1" stop-color="#1aa9e8" /></radialGradient
						>
						<radialGradient
							id="a472a647-94c4-48a3-a4ff-c546c6d0522e"
							cx="-774.36"
							cy="721.07"
							r="1"
							gradientTransform="matrix(100.19, -350.44, -418.92, -119.77, 379827.03, -184632.73)"
							gradientUnits="userSpaceOnUse"
							><stop offset="0.45" stop-color="#ffd953" />
							<stop offset="0.74" stop-color="#fbab33" />
							<stop offset="1" stop-color="#ef8523" /></radialGradient
						>
						<radialGradient
							id="e5d1713c-65a6-46d4-9d69-0c85940c7ca1"
							cx="-770.54"
							cy="719.06"
							r="1"
							gradientTransform="matrix(125.74, 73.93, 88.38, -150.31, 33358.79, 165213.36)"
							gradientUnits="userSpaceOnUse"
							><stop offset="0" stop-color="#fcacf1" /> <stop offset="0.45" stop-color="#fcacf1" />
							<stop offset="0.74" stop-color="#fe9887" />
							<stop offset="1" stop-color="#ef4225" /></radialGradient
						></defs
					>
					<path
						d="M262.1,15.8a10,10,0,0,1,11.5,2.43l39.07,43.31a10,10,0,0,1,1.23,11.69l-29.12,50.54a10,10,0,0,1-10.73,4.79L217,116.49a10,10,0,0,1-7.87-8.74l-6.15-58a10,10,0,0,1,5.87-10.18Z"
						transform="translate(-11.22 -14.93)"
						class="e6a19419-ca4e-4fc8-919d-c225b495789d"
					/>
					<path
						d="M145.78,54a10,10,0,0,1,16.77-4.34L319.36,209.26A10,10,0,0,1,314.73,226L98.14,282A10,10,0,0,1,86,269.62Z"
						transform="translate(-11.22 -14.93)"
						class="ff645115-978f-4749-91b7-0655df25f0da"
					/>
					<rect
						x="29.59"
						y="126.31"
						width="119.39"
						height="119.38"
						rx="10"
						transform="translate(-127.49 153.31) rotate(-59.42)"
						class="f4cdc8fd-f942-49df-83d2-702a58c7e32f"
					/></svg
				>
			</div>
			<div class="content-h absolute top-[33%] left-[15%] ">
				<span class="text-5xl font-bold">Curriculum</span>
				<button class="arrow-h"
					><svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 25" role="img"
						><path
							fill-rule="evenodd"
							clip-rule="evenodd"
							d="M16.961 18.085a.459.459 0 0 0 .023.68.545.545 0 0 0 .732-.02l5.648-5.592.333-.33-.333-.33-5.572-5.516a.545.545 0 0 0-.732-.02.459.459 0 0 0-.023.68l4.76 4.712H.713c-.276 0-.5.224-.498.5 0 .276.226.5.502.5h21.028l-4.784 4.736Z"
						/></svg
					></button
				>
			</div>
		</div>
	</div>
</section>

<style>
	.highlight {
		margin-top: 20px;
	}
	.highlight .arrow-h svg {
		fill: #000;
		width: 24px;
		height: 24px;
		transition: all 0.4s ease;
	}

	.highlight .arrow-h {
		background: white;
		margin-top: 9px;
		width: 48px;
		height: 48px;
		display: flex;
		align-items: center;
		justify-content: center;
		border-radius: 50%;
		transition: background-color 0.4s ease, background 0.4s ease, color 0.4s ease;
		box-shadow: -1px -6px 10px hsl(0deg 0% 100% / 25%), 0 6px 10px rgb(5 25 122 / 10%);
	}

	.content-h {
		z-index: 2;
		/* position: absolute;
		top: 56%;
		left: 50%;
		transform: translate(-50%, -50%); */
		display: flex;
		flex-direction: column;
		align-items: center;
		justify-content: center;
	}

	.highlight:hover .arrow-h {
		background: black;
	}
	.highlight:hover svg {
		fill: white;
	}
</style>
