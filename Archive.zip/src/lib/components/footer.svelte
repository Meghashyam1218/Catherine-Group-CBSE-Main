<section class="h-[125h]">
    <div>
        <div class="bg-[#0c1637] h-[125vh] rounded-t-[40px]">
            <div class="bg-cover h-[75vh] rounded-[40px]" style="background-image: url(./bgfooter.webp);">
                <div class="3xs:h-[75vh] md:h-[75vh] backdrop-blur-none rounded-[40px] grid place-content-center">
                    <div class="grid place-items-center">
                        <span class="font-extrabold text-white 3xs:text-[60px] xs:text-[90px] sm:text-[150px] 2md:text-[180px] 3xs:leading-[90px] md:leading-[150px] text-center">TAKE THE<br>PLUNGE!</span>
                    </div>
                    <div class="flex justify-center mt-2">
                        <span class="font-semibold text-white 3xs:text-3xl md:text-4xl text-center">Let the ocean be your classroom</span>
                    </div>
                    <div class="flex justify-center 2xs:mt-4">
                        <button class="flex flex-row bg-white shadow-2xl shadow-gray-600 text-[#0c1637] xl:text-xl text-base font-medium p-2 xl:p-4 rounded-full duration-700 hover:bg-[#0c1637] hover:text-white">
                            <img class="px-3 rotate-[315deg]" src="./arrow.svg"> Explore Our Resources
                        </button>
                    </div>
                </div>
            </div>
            <div class="h-[50vh] flex 3xs:flex-col md:flex-row p-6">
                <div class=" md:w-[60%] flex flex-col justify-between md:py-8">
                    <div><p class="text-start text-white font-semibold 3xs:text-xl md:text-3xl mr-[5%]">Ocean School is built by an
                        interdisciplinary team working at the intersection of science, education and storytelling.</p>
                    </div>
                    <div class="flex 3xs:flex-col md:flex-row">
                        <button class="flex flex-row group justify-between items-center 3xs:px-2 2md:px-8 duration-700 bg-gradient-to-r hover:bg-gradient-to-t from-[#6edad8] via-[#64d9d6] to-[#1aa9e8] 3xs:w-[100%] md:w-[55%] 2md:w-[45%] 3xs:my-4 sm:my-0 h-[10vh] rounded-3xl">
                            <a href="#"><p class="font-semibold text-xl group-hover:text-2xl duration-300">Our Newspaper</p></a>
                            <a href="#">
                                <div class="bg-white h-[50px] group-hover:h-[55px] w-[50px] group-hover:w-[55px] duration-300 rounded-full grid place-items-center">
                                    <img class="" src="./arrow.svg">
                                </div>
                            </a>
                        </button>
                        <div class="grid grid-cols-5 items-center px-8 3xs:my-4 md:my-0 justify-items-center 3xs:w-[100%] md:w-[50%]">
                            <div><a href=""><img src="./facebook.svg" alt="#"></a></div>
                            <div><a href=""><img src="./instagram.svg" alt="#"></a></div>
                            <div><a href=""><img src="./youtube.svg" alt="#"></a></div>
                            <div><a href=""><img src="./twitter.svg" alt="#"></a></div>
                            <div><a href=""><img src="./linkedin.svg" alt="#"></a></div>
                        </div>
                    </div>
                </div>
                <div class="flex 3xs:flex-col 2xs:flex-row justify-between text-white 3xs:w-[100%] md:w-[50%] pt-6">
                    <div class="w-[60%] xl:w-[50%]">
                        <div class="pb-2 w-max"><p class="sm:hover:text-xl duration-300">Accessibility on Ocean School</p>
                        </div>
                        <div class="pb-2 w-max"><p class="sm:hover:text-xl duration-300">Privacy policy</p></div>
                        <div class="pb-2 w-max"><p class="sm:hover:text-xl duration-300">Terms and conditions</p></div>
                        <div class="pb-2 w-max"><p class="sm:hover:text-xl duration-300">Credits</p></div>
                    </div>
                    <div class="w-[30%] xl:w-[50%]">
                        <div class="pb-2 w-max"><p class="sm:hover:text-xl duration-300">Help Centre</p></div>
                        <div class="pb-2 w-max"><p class="sm:hover:text-xl duration-300">Partners</p></div>
                        <div class="pb-2 w-max"><p class="sm:hover:text-xl duration-300">NFB Education</p></div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>